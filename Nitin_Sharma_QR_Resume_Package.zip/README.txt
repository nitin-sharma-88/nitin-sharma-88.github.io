NITIN SHARMA — QR RESUME PACKAGE

Files:
1. index.html — web version of the resume
2. Nitin_Sharma_Resume.docx — original editable resume

IMPORTANT:
A QR code can only point to a publicly reachable web address. This package is ready to upload to a static hosting service (for example GitHub Pages). After uploading, use the resulting public URL to generate the final QR code.

The QR code should point to:
https://YOUR-PUBLIC-HOST/index.html

Once you have the public URL, the QR can be generated and placed on the resume.
